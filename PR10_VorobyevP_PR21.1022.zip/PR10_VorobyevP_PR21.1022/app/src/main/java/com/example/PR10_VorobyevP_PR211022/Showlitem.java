package com.example.PR10_VorobyevP_PR21.102;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Showlitem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borsh);
    }
}