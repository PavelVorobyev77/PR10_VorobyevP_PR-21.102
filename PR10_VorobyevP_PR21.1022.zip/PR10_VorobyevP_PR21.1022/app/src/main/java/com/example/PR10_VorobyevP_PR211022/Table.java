package com.example.PR10_VorobyevP_PR21.102;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Table extends AppCompatActivity {
    ImageButton imageButton7; // стрелка
    Button button5; //борщ
    Button button6; //цезарь
    Button button7; //блины
    Button button8; //мол.кок
    Button button9; //спагет

    Intent intentbot1;
    Intent intentbot2;
    Intent intentbot3;
    Intent intentbot4;
    Intent intentbot6;
    Intent intentbot7;

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_table_of_dishes);

            imageButton7 = (ImageButton)findViewById(R.id.imageButton7);
            button5= (Button)findViewById(R.id.button5);
            button6 = (Button)findViewById(R.id.button6);
            button7 = (Button)findViewById(R.id.button7);
            button8 = (Button)findViewById(R.id.button8);
            button9 = (Button)findViewById(R.id.button9);


            {   final Intent intentbot1 = new Intent();
                intentbot1.setClass(Table.this, MainActivity.class);
                imageButton7.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(intentbot1);
                    }});}
            {
                final Intent intentbot2 = new Intent();
                intentbot2 .setClass(Table.this, Showlitem.class);
                button5.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(intentbot2 );
                    }});}

            { final Intent intentbot3 = new Intent();
                intentbot3 .setClass(Table.this, Showlitem1.class);
                button6.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(intentbot3 );
                    }});
            }
            { final Intent intentbot4 = new Intent();
                intentbot4 .setClass(Table.this, Showlitem1.class);
                button6.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(intentbot4 );
                    }});

                { final Intent intentbot5 = new Intent();
                    intentbot5 .setClass(Table.this, Showlitem2.class);
                    button7.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            startActivity(intentbot5 );
                        }});
                }
                { final Intent intentbot6 = new Intent();
                    intentbot6 .setClass(Table.this, Showlitem3.class);
                    button8.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            startActivity(intentbot6 );
                        }});
                }
                { final Intent intentbot7 = new Intent();
                    intentbot7 .setClass(Table.this, Showlitem4.class);
                    button9.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            startActivity(intentbot7);
                        }});
                }
    }
}
}
